import os
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
import uvicorn
import numpy as np
import joblib
from PIL import Image
import io
from skimage.feature import hog
from skimage.color import rgb2gray

app = FastAPI(title="Diabetic Foot Ulcer Detection API")

# تحميل النموذج وترميز الفئات عند بدء تشغيل الخادم
MODEL_PATH = "best_lightgbm_model.pkl"
ENCODER_PATH = "label_encoder.pkl"

if os.path.exists(MODEL_PATH) and os.path.exists(ENCODER_PATH):
    model = joblib.load(MODEL_PATH)
    le = joblib.load(ENCODER_PATH)
    print("✅ تم تحميل النموذج والمحولات بنجاح!")
else:
    raise FileNotFoundError("تنبيه: لم يتم العثور على ملفات النموذج المحفوظة.")

def preprocess_image(image_bytes):
    """
    تنظيف ومعالجة الصورة بنفس الخطوات الدقيقة المستخدمة أثناء التدريب:
    1. تحويل الصورة وتعديل حجمها إلى 224x224 وتأمين نظام الألوان RGB.
    2. استخراج ميزات الحواف (HOG).
    3. استخراج ميزات الألوان (Color Histograms).
    4. دمج الميزات واستخراج المتجه النهائي للتوقع.
    """
    # قراءة الصورة
    img = Image.open(io.BytesIO(image_bytes))
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # تغيير الحجم الموحد
    img_resized = img.resize((224, 224), Image.Resampling.LANCZOS)
    img_array = np.array(img_resized)
    
    # 1. استخراج ميزات الحواف (HOG)
    gray_img = rgb2gray(img_array)
    hog_feat = hog(gray_img, orientations=8, pixels_per_cell=(16, 16),
                   cells_per_block=(1, 1), visualize=False)
    
    # 2. استخراج ميزات الألوان لثلاث قنوات R, G, B
    hist_r, _ = np.histogram(img_array[:, :, 0], bins=8, range=(0, 256), density=True)
    hist_g, _ = np.histogram(img_array[:, :, 1], bins=8, range=(0, 256), density=True)
    hist_b, _ = np.histogram(img_array[:, :, 2], bins=8, range=(0, 256), density=True)
    color_feat = np.concatenate([hist_r, hist_g, hist_b])
    
    # دمج الميزات بنفس ترتيب الأعمدة الافتراضية
    combined_feat = np.concatenate([hog_feat, color_feat]).reshape(1, -1)
    return combined_feat

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    try:
        # قراءة الملف المرسل من تطبيق فلاتر
        contents = await file.read()
        
        # المعالجة المسبقة والتنظيف
        features = preprocess_image(contents)
        
        # التنبؤ باستخدام النموذج المحفوظ
        prediction_idx = model.predict(features)[0]
        prediction_prob = model.predict_proba(features)[0]
        
        # فك الترميز لمعرفة الفئة الطبية الحقيقية
        class_name = le.inverse_transform([prediction_idx])[0]
        confidence = float(max(prediction_prob))
        
        return JSONResponse({
            "status": "success",
            "class_name": class_name,
            "confidence": confidence,
            "probabilities": {
                le.classes_[0]: float(prediction_prob[0]),
                le.classes_[1]: float(prediction_prob[1])
            }
        })
    except Exception as e:
        return JSONResponse({
            "status": "error",
            "message": str(e)
        }, status_code=500)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
